import { Sequelize } from "sequelize";
import db from "../config/Database.js";
import Kategori from "./KategoriModel.js";
import Users from "./UserModel.js";


const {DataTypes} = Sequelize;

const SubKategori = db.define('subkategori',{
    uuid:{
        type: DataTypes.STRING,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },

    subkategoriId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        primaryKey: true,
        validate:{
            notEmpty: true
        } 
    },

    kategoriId: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        validate:{
            notEmpty: true
        } 
    },

    subkategoriname:{
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            notEmpty: true,
            len: [3,100]
        }
    },

    subkategoricode:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },


    userId:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    }

    


},{
    freezeTableName: true,
});

Users.hasMany(SubKategori);
SubKategori.belongsTo(Users,{foreignKey:'userId'});
SubKategori.belongsTo(Kategori,{foreignKey:'kategoriId'});


export default SubKategori;

