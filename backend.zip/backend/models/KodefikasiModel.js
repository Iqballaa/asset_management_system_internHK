import { Sequelize } from "sequelize";
import db from "../config/Database.js";
import Users from "./UserModel.js";
import Gerbang from "./GerbangModel.js";
import Ruas from "./RuasModel.js";
import Kategori from"./KategoriModel.js";
import SubKategori from "./SubKategoriModel.js";

const {DataTypes} = Sequelize;

const Kodefikasi = db.define('kodefikasi',{
    uuid:{
        type: DataTypes.STRING,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },


    kodefikasiId: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
        validate:{
            notEmpty: true
        } 
    },

    gerbangname:{
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            notEmpty: true,
            len: [3,100]
        }
    },

    gerbangcode:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },

    ruasname:{
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            notEmpty: true,
            len: [3,100]
        }
    },

    ruascode:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },


    kategoriname:{
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            notEmpty: true,
            len: [3,100]
        }
    },

    kategoricode:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },


    subkategoriname:{
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            notEmpty: true,
            len: [3,100]
        }
    },

    subkategoricode:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },

    gerbangId: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        validate:{
            notEmpty: true
        } 
    },

    ruasId: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        validate:{
            notEmpty: true
        } 
    },

    kategoriId: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        validate:{
            notEmpty: true
        } 
    },

    subkategoriId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate:{
            notEmpty: true
        } 
    },

    userId:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    }


},{
    freezeTableName: true,
});

Users.hasMany(Kodefikasi);
Kodefikasi.belongsTo(Users,{foreignKey:'userId'});
Kodefikasi.belongsTo(Ruas,{foreignKey:'ruasId'});
Kodefikasi.belongsTo(Gerbang,{foreignKey:'gerbangId'});
Kodefikasi.belongsTo(Kategori,{foreignKey:'kategoriId'});
Kodefikasi.belongsTo(SubKategori,{foreignKey:'subkategoriId'});


export default Kodefikasi;

