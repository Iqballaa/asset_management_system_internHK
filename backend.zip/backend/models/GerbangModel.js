import { Sequelize } from "sequelize";
import db from "../config/Database.js";
import Users from "./UserModel.js";
import Ruas from "./RuasModel.js";

const {DataTypes} = Sequelize;

const Gerbang = db.define('gerbang',{

    uuid:{
        type: DataTypes.STRING,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },


    ruasId: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        validate:{
            notEmpty: true
        } 
    },

    gerbangId: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
        validate:{
            notEmpty: true
        } 
    },

    gerbangname:{
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            notEmpty: true,
            len: [3,100]
        }
    },

    gerbangcode:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },


    gerbanglocation:{
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            notEmpty: true,
            len: [3,100]
        }
    },

    userId:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    }


},{
    freezeTableName: true,
});

Users.hasMany(Gerbang);
Gerbang.belongsTo(Users,{foreignKey:'userId'});
Gerbang.belongsTo(Ruas,{foreignKey:'ruasId'});

export default Gerbang;

