import Ruas from "../models/RuasModel.js";
import User from "../models/UserModel.js";
import {Op} from "sequelize";

export const getRuas = async (req, res) =>{
    try {
        let response;
        if(req.role === "admin"){
            response = await Ruas.findAll({
                attributes:['uuid','ruasId','ruasname','ruascode','ruaslength', 'ruaslocation', 'branches'],
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }else{
            response = await Ruas.findAll({
                attributes:['uuid','ruasId','ruasname','ruascode','ruaslength', 'ruaslocation', 'branches'],
                where:{
                    userId: req.userId
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const getRuasById = async(req, res) =>{
    try {
        const ruas = await Ruas.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!ruas) return res.status(404).json({msg: "Data tidak ditemukan"});
        let response;
        if(req.role === "admin"){
            response = await Ruas.findOne({
                attributes:['uuid','ruasId','ruasname','ruascode','ruaslength', 'ruaslocation', 'branches'],
                where:{
                    id: ruas.id
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }else{
            response = await Ruas.findOne({
                attributes:['uuid','ruasId','ruasname','ruascode','ruaslength', 'ruaslocation', 'branches'],
                where:{
                    [Op.and]:[{id: ruas.id}, {userId: req.userId}]
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const createRuas = async(req, res) =>{
    const {ruasname, ruascode, ruaslength, ruaslocation, branches} = req.body;
    try {
        await Ruas.create({
            ruasname: ruasname,
            ruascode: ruascode,
            ruaslength: ruaslength,
            ruaslocation: ruaslocation,
            branches: branches,
            userId: req.userId
        });
        res.status(201).json({msg: "Ruas Created Successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const updateRuas = async(req, res) =>{
    try {
        const ruas = await Ruas.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!ruas) return res.status(404).json({msg: "Data tidak ditemukan"});
        const {ruasname, ruascode, ruaslength, ruaslocation, branches} = req.body;
        if(req.role === "admin"){
            await Ruas.update({ruasname, ruascode,ruaslength, ruaslocation, branches},{
                where:{
                    id: ruas.id
                }
            });
        }else{
            if(req.userId !== ruas.userId) return res.status(403).json({msg: "Akses terlarang"});
            await Ruas.update({ruasname, ruascode, ruaslength, ruaslocation, branches},{
                where:{
                    [Op.and]:[{id: ruas.id}, {userId: req.userId}]
                }
            });
        }
        res.status(200).json({msg: "Ruas updated successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const deleteRuas = async(req, res) =>{
    try {
        const ruas = await Ruas.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!ruas) return res.status(404).json({msg: "Data tidak ditemukan"});
        const {ruasname, ruascode, ruaslength, ruaslocation, branches} = req.body;
        if(req.role === "admin"){
            await Ruas.destroy({
                where:{
                    id: ruas.id
                }
            });
        }else{
            if(req.userId !== ruas.userId) return res.status(403).json({msg: "Akses terlarang"});
            await Ruas.destroy({
                where:{
                    [Op.and]:[{id: ruas.id}, {userId: req.userId}]
                }
            });
        }
        res.status(200).json({msg: "Ruas change it successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}