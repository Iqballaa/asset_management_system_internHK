import Kodefikasi from "../models/KodefikasiModel.js";
import User from "../models/UserModel.js";
import Ruas from "../models/RuasModel.js";
import Gerbang from "../models/GerbangModel.js";
import Kategori from "../models/KategoriModel.js";
import SubKategori from "../models/SubKategoriModel.js";
import {Op} from "sequelize";

export const getKodefikasi = async (req, res) =>{
    try {
        let response;
        if(req.role === "admin"){
            response = await Kodefikasi.findAll({
                attributes:['uuid','kodefikasiId'],
                include:[{
                    model: User, Gerbang, Ruas, Kategori, SubKategori,
                    attributes:['name','email','gerbangname','gerbangcode','ruasname','ruascode','kategoriname','kategoricode','subkategoriname','subkategoricode']
                }]
            });
        }else{
            response = await Kodefikasi.findAll({
                attributes:['uuid','kodefikasiId'],
                where:{
                    userId: req.userId
                },
                include:[{
                    model: User, Gerbang, Ruas, Kategori, SubKategori,
                    attributes:['name','email','gerbangname','gerbangcode','ruasname','ruascode','kategoriname','kategoricode','subkategoriname','subkategoriname']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const getKodefikasiById = async(req, res) =>{
    try {
        const kodefikasi = await Kodefikasi.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!product) return res.status(404).json({msg: "Data tidak ditemukan"});
        let response;
        if(req.role === "admin"){
            response = await Kodefikasi.findOne({
                attributes:['uuid','kodefikasiId'],
                where:{
                    id: kodefikasi.id
                },
                include:[{
                    model: User, Gerbang, Ruas, Kategori, SubKategori,
                    attributes:['name','email', 'gerbangname','gerbangcode','ruasname','ruascode','kategoriname','kategoricode','subkategoriname','subkategoricode']
                }]
            });
        }else{
            response = await Kodefikasi.findOne({
                attributes:['uuid','kodefikasiId'],
                where:{
                    [Op.and]:[{id: kodefikasi.id}, {userId: req.userId}]
                },
                include:[{
                    model: User, Gerbang, Ruas, Kategori, SubKategori,
                    attributes:['name','email','gerbangname', 'gerbangcode','ruasname','ruascode','kategoriname','kategoricode','subkategoriname','subkategoricode']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}
