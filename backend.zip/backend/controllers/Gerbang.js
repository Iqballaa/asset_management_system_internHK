import Gerbang from "../models/GerbangModel.js";
import User from "../models/UserModel.js";
import Ruas from "../models/RuasModel.js";
import {Op} from "sequelize";

export const getGerbang = async (req, res) =>{
    try {
        let response;
        if(req.role === "admin"){
            response = await Gerbang.findAll({
                attributes:['uuid','gerbangId','gerbangname','gerbangcode', 'gerbanglocation'],
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }else{
            response = await Gerbang.findAll({
                attributes:['uuid','gerbangId','gerbangname','gerbangcode', 'gerbanglocation'],
                where:{
                    userId: req.userId
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const getGerbangById = async(req, res) =>{
    try {
        const gerbang = await Gerbang.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!gerbang) return res.status(404).json({msg: "Data tidak ditemukan"});
        let response;
        if(req.role === "admin"){
            response = await Gerbang.findOne({
                attributes:['uuid','gerbangId','gerbangname','gerbangcode', 'gerbanglocation'],
                where:{
                    id: gerbang.id
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }else{
            response = await Gerbang.findOne({
                attributes:['uuid','gerbangId','gerbangname','gerbangcode', 'gerbanglocation'],
                where:{
                    [Op.and]:[{id: gerbang.id}, {userId: req.userId}]
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const createGerbang = async(req, res) =>{
    const {gerbangname, gerbangcode} = req.body;
    try {
        await Gerbang.create({
            gerbangname: gerbangname,
            gerbangcode: gerbangcode,
            gerbanglocation: gerbanglocation,
            userId: req.userId
        });
        res.status(201).json({msg: "Gerbang Created Successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const updateGerbang = async(req, res) =>{
    try {
        const gerbang = await Gerbang.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!gerbang) return res.status(404).json({msg: "Data tidak ditemukan"});
        const {gerbangname, gerbangcode, gerbanglocation} = req.body;
        if(req.role === "admin"){
            await Gerbang.update({gerbangname, gerbangcode, gerbanglocation},{
                where:{
                    id: gerbang.id
                }
            });
        }else{
            if(req.userId !== gerbang.userId) return res.status(403).json({msg: "Akses terlarang"});
            await Gerbang.update({gerbangname, gerbangcode, gerbanglocation},{
                where:{
                    [Op.and]:[{id: gerbang.id}, {userId: req.userId}]
                }
            });
        }
        res.status(200).json({msg: "Gerbang updated successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const deleteGerbang = async(req, res) =>{
    try {
        const gerbang = await Gerbang.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!gerbang) return res.status(404).json({msg: "Data tidak ditemukan"});
        const {gerbangname, gerbangcode, gerbanglocation} = req.body;
        if(req.role === "admin"){
            await Gerbang.destroy({
                where:{
                    id: gerbang.id
                }
            });
        }else{
            if(req.userId !== gerbang.userId) return res.status(403).json({msg: "Akses terlarang"});
            await Gerbang.destroy({
                where:{
                    [Op.and]:[{id: gerbang.id}, {userId: req.userId}]
                }
            });
        }
        res.status(200).json({msg: "Gerbang change it successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}