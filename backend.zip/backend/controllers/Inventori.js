import Inventori from "../models/InventoriModel.js";
import User from "../models/UserModel.js";
import Gerbang from "../models/GerbangModel.js";
import {Op} from "sequelize";

export const getInventori = async (req, res) =>{
    try {
        let response;
        if(req.role === "admin"){
            response = await Inventori.findAll({
                attributes:['uuid','inventoriId','merk_asset','tanggal_terima_asset','assetlocation','tahun_perolehan_asset','harga_perolehan_asset','batas_pemakaian_asset','nilai_penyusutan_asset','waktu_penyusutan','kondisi_asset'],
                include:[{
                    model: User, Gerbang,
                    attributes:['name','email','gerbangname','gerbangcode']
                }]
            });
        }else{
            response = await Inventori.findAll({
                attributes:['uuid','inventoriId','merk_asset','tanggal_terima_asset','assetlocation','tahun_perolehan_asset','harga_perolehan_asset','batas_pemakaian_asset','nilai_penyusutan_asset','waktu_penyusutan_asset','kondisi_asset'],
                where:{
                    userId: req.userId
                },
                include:[{
                    model: User, Gerbang,
                    attributes:['name','email','gerbangname','gerbangcode']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const getInventoriById = async(req, res) =>{
    try {
        const inventori = await Inventori.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!inventori) return res.status(404).json({msg: "Inventori tidak dapat muncul"});
        let response;
        if(req.role === "admin"){
            response = await Inventori.findOne({
                attributes:['uuid','inventoriId','merk_asset','tanggal_terima_asset','assetlocation','tahun_perolehan_asset','harga_perolehan_asset','batas_pemakaian_asset','nilai_penyusutan_asset','waktu_penyusutan_asset','kondisi_asset'],
                where:{
                    id: inventori.id
                },
                include:[{
                    model: User, Gerbang,
                    attributes:['name','email','gerbangname','gerbangcode']
                }]
            });
        }else{
            response = await Inventori.findOne({
                attributes:['uuid','inventoriId','merk_asset','tanggal_terima_asset','assetlocation','tahun_perolehan_asset','harga_perolehan_asset','batas_pemakaian_asset','nilai_penyusutan_asset','waktu_penyusutan_asset','kondisi_asset'],
                where:{
                    [Op.and]:[{id: inventori.id}, {userId: req.userId}]
                },
                include:[{
                    model: User, Gerbang,
                    attributes:['name','email','gerbangname','gerbangcode']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const createInventori = async(req, res) =>{
    const {merk_asset,tanggal_terima_asset,assetlocation,tahun_perolehan_asset,harga_perolehan_asset,batas_pemakaian_asset,nilai_penyusutan_asset,waktu_penyusutan_asset,kondisi_asset} = req.body;
    try {
        await Inventori.create({
            merk_asset: merk_asset,
            tanggal_terima_asset: tanggal_terima_asset,
            assetlocation: assetlocation,
            tahun_perolehan_asset: tahun_perolehan_asset,
            harga_perolehan_asset: harga_perolehan_asset,
            batas_pemakaian_asset: batas_pemakaian_asset,
            nilai_penyusutan_asset: nilai_penyusutan_asset ,
            waktu_penyusutan_asset: waktu_penyusutan_asset,
            kondisi_asset: kondisi_asset,
            userId: req.userId
        });
        res.status(201).json({msg: "Inventori Created Successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const updateInventori = async(req, res) =>{
    try {
        const inventori = await Inventori.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!inventori) return res.status(404).json({msg: "Data tidak ditemukan"});
        const {merk_asset,tanggal_terima_asset,assetlocation,tahun_perolehan_asset,harga_perolehan_asset,batas_pemakaian_asset,nilai_penyusutan_asset,waktu_penyusutan_asset,kondisi_asset} = req.body;
        if(req.role === "admin"){
            await Inventori.update({merk_asset,tanggal_terima_asset,assetlocation,tahun_perolehan_asset,harga_perolehan_asset,batas_pemakaian_asset,nilai_penyusutan_asset,waktu_penyusutan_asset,kondisi_asset},{
                where:{
                    id: inventori.id
                }
            });
        }else{
            if(req.userId !== inventori.userId) return res.status(403).json({msg: "Akses terlarang"});
            await Inventori.update({merk_asset,tanggal_terima_asset,assetlocation,tahun_perolehan_asset,harga_perolehan_asset,batas_pemakaian_asset,nilai_penyusutan_asset,waktu_penyusutan_asset,kondisi_asset},{
                where:{
                    [Op.and]:[{id: inventori.id}, {userId: req.userId}]
                }
            });
        }
        res.status(200).json({msg: "Inventori updated successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const deleteInventori = async(req, res) =>{
    try {
        const inventori = await Inventori.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!inventori) return res.status(404).json({msg: "Data tidak ditemukan"});
        const {merk_asset,tanggal_terima_asset,assetlocation,tahun_perolehan_asset,harga_perolehan_asset,batas_pemakaian_asset,nilai_penyusutan_asset,waktu_penyusutan_asset,kondisi_asset} = req.body;
        if(req.role === "admin"){
            await Inventori.destroy({
                where:{
                    id: inventori.id
                }
            });
        }else{
            if(req.userId !== inventori.userId) return res.status(403).json({msg: "Akses terlarang"});
            await Inventori.destroy({
                where:{
                    [Op.and]:[{id: inventori.id}, {userId: req.userId}]
                }
            });
        }
        res.status(200).json({msg: "Inventori change it successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}