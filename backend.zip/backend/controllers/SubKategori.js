import SubKategori from "../models/SubKategoriModel.js";
import User from "../models/UserModel.js";
import {Op} from "sequelize";

export const getSubKategori = async (req, res) =>{
    try {
        let response;
        if(req.role === "admin"){
            response = await SubKategori.findAll({
                attributes:['uuid','subkategoriId','subkategoriname','subkategoricode'],
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }else{
            response = await SubKategori.findAll({
                attributes:['uuid','subkategoriId','subkategoriname','subkategoricode'],
                where:{
                    userId: req.userId
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const getSubKategoriById = async(req, res) =>{
    try {
        const subkategori = await SubKategori.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!subkategori) return res.status(404).json({msg: "Kategori tidak dapat muncul"});
        let response;
        if(req.role === "admin"){
            response = await SubKategori.findOne({
                attributes:['uuid','subkategoriId','subkategoriname','subkategoricode'],
                where:{
                    id: subkategori.id
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }else{
            response = await SubKategori.findOne({
                attributes:['uuid','subkategoriId','subkategoriname','subkategoricode'],
                where:{
                    [Op.and]:[{id: subkategori.id}, {userId: req.userId}]
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const createSubKategori = async(req, res) =>{
    const {subkategoriname, subkategoricode} = req.body;
    try {
        await Kategori.create({
            subkategoriname: subkategoriname,
            subkategoricode: subkategoricode,
            userId: req.userId
        });
        res.status(201).json({msg: "Kategori Created Successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const updateSubKategori = async(req, res) =>{
    try {
        const subkategori = await SubKategori.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!subkategori) return res.status(404).json({msg: "Data tidak ditemukan"});
        const {subkategoriname, subkategoricode} = req.body;
        if(req.role === "admin"){
            await SubKategori.update({subkategoriname, subkategoricode},{
                where:{
                    id: subkategori.id
                }
            });
        }else{
            if(req.userId !== subkategori.userId) return res.status(403).json({msg: "Akses terlarang"});
            await SubKategori.update({subkategoriname, subkategoricode},{
                where:{
                    [Op.and]:[{id: subkategori.id}, {userId: req.userId}]
                }
            });
        }
        res.status(200).json({msg: "Kategori updated successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const deleteSubKategori = async(req, res) =>{
    try {
        const subkategori = await SubKategori.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!subkategori) return res.status(404).json({msg: "Data tidak ditemukan"});
        const {subkategoriname, subkategoricode} = req.body;
        if(req.role === "admin"){
            await SubKategori.destroy({
                where:{
                    id: subkategori.id
                }
            });
        }else{
            if(req.userId !== subkategori.userId) return res.status(403).json({msg: "Akses terlarang"});
            await SubKategori.destroy({
                where:{
                    [Op.and]:[{id: subkategori.id}, {userId: req.userId}]
                }
            });
        }
        res.status(200).json({msg: "Kategori change it successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}