import Kategori from "../models/KategoriModel.js";
import User from "../models/UserModel.js";
import {Op} from "sequelize";

export const getKategori = async (req, res) =>{
    try {
        let response;
        if(req.role === "admin"){
            response = await Kategori.findAll({
                attributes:['uuid','kategoriId','kategoriname','kategoricode'],
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }else{
            response = await Kategori.findAll({
                attributes:['uuid','kategoriId','kategoriname','kategoricode'],
                where:{
                    userId: req.userId
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const getKategoriById = async(req, res) =>{
    try {
        const kategori = await Kategori.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!kategori) return res.status(404).json({msg: "Kategori tidak dapat muncul"});
        let response;
        if(req.role === "admin"){
            response = await Kategori.findOne({
                attributes:['uuid','kategoriId','kategoriname','kategoricode'],
                where:{
                    id: kategori.id
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }else{
            response = await Kategori.findOne({
                attributes:['uuid','kategoriId','kategoriname','kategoricode'],
                where:{
                    [Op.and]:[{id: kategori.id}, {userId: req.userId}]
                },
                include:[{
                    model: User,
                    attributes:['name','email']
                }]
            });
        }
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const createKategori = async(req, res) =>{
    const {kategoriname, kategoricode} = req.body;
    try {
        await Kategori.create({
            kategoriname: kategoriname,
            kategoricode: kategoricode,
            userId: req.userId
        });
        res.status(201).json({msg: "Kategori Created Successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const updateKategori = async(req, res) =>{
    try {
        const kategori = await Kategori.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!kategori) return res.status(404).json({msg: "Data tidak ditemukan"});
        const {kategoriname, kategoricode} = req.body;
        if(req.role === "admin"){
            await Kategori.update({kategoriname, kategoricode},{
                where:{
                    id: kategori.id
                }
            });
        }else{
            if(req.userId !== kategori.userId) return res.status(403).json({msg: "Akses terlarang"});
            await Kategori.update({kategoriname, kategoricode},{
                where:{
                    [Op.and]:[{id: kategori.id}, {userId: req.userId}]
                }
            });
        }
        res.status(200).json({msg: "Kategori updated successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

export const deleteKategori = async(req, res) =>{
    try {
        const kategori = await Kategori.findOne({
            where:{
                uuid: req.params.id
            }
        });
        if(!kategori) return res.status(404).json({msg: "Data tidak ditemukan"});
        const {kategoriname, kategoricode} = req.body;
        if(req.role === "admin"){
            await Kategori.destroy({
                where:{
                    id: kategori.id
                }
            });
        }else{
            if(req.userId !== kategori.userId) return res.status(403).json({msg: "Akses terlarang"});
            await Kategori.destroy({
                where:{
                    [Op.and]:[{id: kategori.id}, {userId: req.userId}]
                }
            });
        }
        res.status(200).json({msg: "Kategori change it successfuly"});
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}