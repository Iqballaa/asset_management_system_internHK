import  express from "express";

import {
    getSubKategori,
    getSubKategoriById,
    createSubKategori,
    updateSubKategori,
    deleteSubKategori,
} from "../controllers/SubKategori.js";
import { verifyUser } from "../middleware/AuthUser.js";

const router = express.Router();

router.get('/subkategori', verifyUser, getSubKategori);
router.get('/subkategori/:id', verifyUser, getSubKategoriById);
router.post('/subkategori', verifyUser, createSubKategori);
router.patch('/subkategori/:id', verifyUser, updateSubKategori);
router.delete('/subkategori/:id', verifyUser, deleteSubKategori);

export default router ;