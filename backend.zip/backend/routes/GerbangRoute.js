import  express from "express";

import {
    getGerbang,
    getGerbangById,
    createGerbang,
    updateGerbang,
    deleteGerbang,
} from "../controllers/Gerbang.js";
import { verifyUser } from "../middleware/AuthUser.js";

const router = express.Router();

router.get('/gerbang', verifyUser, getGerbang);
router.get('/gerbang/:id', verifyUser, getGerbangById);
router.post('/gerbang', verifyUser, createGerbang);
router.patch('/gerbang/:id', verifyUser, updateGerbang);
router.delete('/gerbang/:id', verifyUser, deleteGerbang);

export default router ;