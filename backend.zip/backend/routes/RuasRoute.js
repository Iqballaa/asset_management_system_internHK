import  express from "express";

import {
    getRuas,
    getRuasById,
    createRuas,
    updateRuas,
    deleteRuas,
} from "../controllers/Ruas.js";
import { verifyUser } from "../middleware/AuthUser.js";

const router = express.Router();

router.get('/ruas', verifyUser, getRuas);
router.get('/ruas/:id', verifyUser, getRuasById);
router.post('/ruas', verifyUser, createRuas);
router.patch('/ruas/:id', verifyUser, updateRuas);
router.delete('/ruas/:id', verifyUser, deleteRuas);

export default router ;