import  express from "express";

import {
    getInventori,
    getInventoriById,
    createInventori,
    updateInventori,
    deleteInventori,
} from "../controllers/Inventori.js";
import { verifyUser } from "../middleware/AuthUser.js";

const router = express.Router();

router.get('/inventori', verifyUser, getInventori);
router.get('/inventori/:id', verifyUser, getInventoriById);
router.post('/inventori', verifyUser, createInventori);
router.patch('/inventori/:id', verifyUser, updateInventori);
router.delete('/inventori/:id', verifyUser, deleteInventori);

export default router ;